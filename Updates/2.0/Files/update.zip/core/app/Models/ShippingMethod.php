<?php

namespace App\Models;

use App\Traits\GlobalStatus;
use Illuminate\Database\Eloquent\Model;

class ShippingMethod extends Model
{
    use GlobalStatus;
}
